﻿<!DOCTYPE html>
<html>
  <head>
    <title>SISVAL-RENAL: Cadastrar novo dado clínico</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <link href="resources/css/jquery-ui-themes.css" type="text/css" rel="stylesheet"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/cadastrardadoclinico/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-1.7.1.min.js"></script>
    <script src="resources/scripts/jquery-ui-1.8.10.custom.min.js"></script>
    <script src="resources/scripts/prototypePre.js"></script>
    <script src="data/document.js"></script>
    <script src="resources/scripts/prototypePost.js"></script>
    <script src="files/cadastrardadoclinico/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
	
	<script type="text/javascript"> 
	//o dNatal será um tipo Date com a data correta conforme o formato informado 
	var dNatal = new Date(getDateFromFormat("25/12/2013 00:00:00", "d/m/yy HH:mm:ss"));
	</script>
	
		<?php
		$codPaciente = $_POST['codPaciente'];
		$nomePaciente = $_POST['nomePaciente'];
		$prontuario = $_POST['prontuario'];
		$nascimento = $_POST['nascimento'];
	    ?>
	
  </head>
  
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u434" class="ax_default paragraph">
        <div id="u434_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u435" class="text" style="display:none; visibility: hidden">
          <p><span></span></p>
        </div>
      </div>

      <!-- Unnamed (Image) -->
      <div id="u436" class="ax_default image">
        <img id="u436_img" class="img " src="images/cadastrardadoclinico/u436.png"/>
        <!-- Unnamed () -->
        <div id="u437" class="text" style="display:none; visibility: hidden">
          <p><span></span></p>
        </div>
      </div>

      <!-- Unnamed (Table) -->
      <div id="u438" class="ax_default">

        <!-- Unnamed (Table Cell) -->
        <div id="u439" class="ax_default table_cell">
          <img id="u439_img" class="img " src="images/cadastrardadoclinico/u439.png"/>
          <!-- Unnamed () -->
          <div id="u440" class="text">
            <p><span>Nome:</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u441" class="ax_default table_cell">
          <img id="u441_img" class="img " src="images/cadastrardadoclinico/u441.png"/>
          <!-- Unnamed () -->
          <div id="u442" class="text">
            <p><span><b>&nbsp;&nbsp; &nbsp;<?php echo $nomePaciente?></b></span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u443" class="ax_default table_cell">
          <img id="u443_img" class="img " src="images/cadastrardadoclinico/u443.png"/>
          <!-- Unnamed () -->
          <div id="u444" class="text">
            <p><span>Data de Nascimento:</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u445" class="ax_default table_cell">
          <img id="u445_img" class="img " src="images/cadastrardadoclinico/u445.png"/>
          <!-- Unnamed () -->
          <div id="u446" class="text">
            <p><span>&nbsp;&nbsp; &nbsp;<b><?php echo $nascimento;?></b></span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u447" class="ax_default table_cell">
          <img id="u447_img" class="img " src="images/cadastrardadoclinico/u447.png"/>
          <!-- Unnamed () -->
          <div id="u448" class="text">
            <p><span>Prontuário:</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u449" class="ax_default table_cell">
          <img id="u449_img" class="img " src="images/cadastrardadoclinico/u449.png"/>
          <!-- Unnamed () -->
          <div id="u450" class="text">
            <p><span><b>&nbsp;&nbsp; &nbsp;<?php echo $prontuario;?></b></span></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Table) -->
      <div id="u451" class="ax_default">

        <!-- Unnamed (Table Cell) -->
        <div id="u452" class="ax_default table_cell">
          <img id="u452_img" class="img " src="images/cadastrardadoclinico/u452.png"/>
          <!-- Unnamed () -->
          <div id="u453" class="text">
            <p><span>Data da Informação</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u454" class="ax_default table_cell">
          <img id="u454_img" class="img " src="images/cadastrardadoclinico/u454.png"/>
          <!-- Unnamed () -->
          <div id="u455" class="text" style="display:none; visibility: hidden">
            <p><span></span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u456" class="ax_default table_cell">
          <img id="u456_img" class="img " src="images/cadastrardadoclinico/u452.png"/>
          <!-- Unnamed () -->
          <div id="u457" class="text">
            <p><span>&nbsp;&nbsp; &nbsp; Faz hemodiálise?</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u458" class="ax_default table_cell">
          <img id="u458_img" class="img " src="images/cadastrardadoclinico/u454.png"/>
          <!-- Unnamed () -->
          <div id="u459" class="text" style="display:none; visibility: hidden">
            <p><span></span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u460" class="ax_default table_cell">
          <img id="u460_img" class="img " src="images/cadastrardadoclinico/u452.png"/>
          <!-- Unnamed () -->
          <div id="u461" class="text">
            <p><span>Possui algum critério de exclusão?</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u462" class="ax_default table_cell">
          <img id="u462_img" class="img " src="images/cadastrardadoclinico/u454.png"/>
          <!-- Unnamed () -->
          <div id="u463" class="text" style="display:none; visibility: hidden">
            <p><span></span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u464" class="ax_default table_cell">
          <img id="u464_img" class="img " src="images/cadastrardadoclinico/u452.png"/>
          <!-- Unnamed () -->
          <div id="u465" class="text">
            <p><span>Data do exame</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u466" class="ax_default table_cell">
          <img id="u466_img" class="img " src="images/cadastrardadoclinico/u454.png"/>
          <!-- Unnamed () -->
          <div id="u467" class="text" style="display:none; visibility: hidden">
            <p><span></span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u468" class="ax_default table_cell">
          <img id="u468_img" class="img " src="images/cadastrardadoclinico/u452.png"/>
          <!-- Unnamed () -->
          <div id="u469" class="text">
            <p><span>Hemoglobina</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u470" class="ax_default table_cell">
          <img id="u470_img" class="img " src="images/cadastrardadoclinico/u454.png"/>
          <!-- Unnamed () -->
          <div id="u471" class="text" style="display:none; visibility: hidden">
            <p><span></span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u472" class="ax_default table_cell">
          <img id="u472_img" class="img " src="images/cadastrardadoclinico/u452.png"/>
          <!-- Unnamed () -->
          <div id="u473" class="text">
            <p><span>Saturação da Transferrina</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u474" class="ax_default table_cell">
          <img id="u474_img" class="img " src="images/cadastrardadoclinico/u454.png"/>
          <!-- Unnamed () -->
          <div id="u475" class="text" style="display:none; visibility: hidden">
            <p><span></span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u476" class="ax_default table_cell">
          <img id="u476_img" class="img " src="images/cadastrardadoclinico/u476.png"/>
          <!-- Unnamed () -->
          <div id="u477" class="text">
            <p><span>Ferritina Sérica</span></p>
          </div>
        </div>

        <!-- Unnamed (Table Cell) -->
        <div id="u478" class="ax_default table_cell">
          <img id="u478_img" class="img " src="images/cadastrardadoclinico/u478.png"/>
          <!-- Unnamed () -->
          <div id="u479" class="text" style="display:none; visibility: hidden">
            <p><span></span></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u480" class="ax_default box_2">
        <div id="u480_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u481" class="text">
          <p><span style="font-family:'Arial Normal', 'Arial';font-weight:400;">&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; </span><span style="font-family:'Arial Negrito', 'Arial Normal', 'Arial';font-weight:700;">SISVAL-RENAL: CADASTRAR DADO CLÍNICO</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u486" class="ax_default paragraph">
        <div id="u486_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u487" class="text">
          <p><span>Para cadastrar dados clínicos para o paciente indicado acima, preencha os campos e clique no botão CADASTRAR.</span></p>
        </div>
      </div>

	   <form action="armazenarDadoClinico.php" method="post" id="cadastrarDCForm">	
		  
		<input name="codPaciente" type="hidden" value="<?php echo $codPaciente;?>">
		<input name="nomePaciente" type="hidden" value="<?php echo $nomePaciente;?>">
		<input name="prontuario" type="hidden" value="<?php echo $prontuario?>">
		<input name="nascimento" type="hidden" value="<?php echo $nascimento?>">
	  
      <!-- dataInfo (Text Field) -->
      <div id="u488" class="ax_default text_field" data-label="dataInfo">
        <input id="data_gabi" type="date" name="dataInfo" value="Date()"/>
      </div>

      <!-- fazHemodialise (Droplist) -->
      <div id="u489" class="ax_default droplist" data-label="fazHemodialise">
        <select id="u489_input" name="tto_dialitico">
			<option value="SIM">SIM, faz hemodiálise.</option>
            <option value="NAO">NÃO, não faz hemodiálise</option>
        </select>
      </div>

      <!-- criterioExclusao (Droplist) -->
      <div id="u490" class="ax_default droplist" data-label="criterioExclusao">
        <select id="u490_input" name="exclusao">
			<option value="NAO">NÃO POSSUI CRITÉRIOS DE EXCLUSÃO</option>
            <option value="Hemocromatose">Hemocromatose</option>
            <option value="Hemossiderose">Hemossiderose</option>
            <option value="Anemia Hemolitica">Anemia Hemolítica</option>
            <option value="Hipersensibilidade">Hipersensibilidade ao Sacarato de Hidróxido de Ferro III</option>
        </select>
      </div>

      <!-- dataExame (Text Field) -->
      <div id="u491" class="ax_default text_field" data-label="dataExame">
        <input id="data_gabi" type="date" name="dataExame" value="Date()"/>
      </div>

      <!-- hemoglobina (Text Field) -->
      <div id="u492" class="ax_default text_field" data-label="hemoglobina">
        <input id="u492_input" type="text" name="hemoglobina" value=""/>
      </div>

      <!-- transferrina (Text Field) -->
      <div id="u493" class="ax_default text_field" data-label="transferrina">
        <input id="u493_input" type="text" name="transferrina" value=""/>
      </div>

      <!-- ferritina (Text Field) -->
      <div id="u494" class="ax_default text_field" data-label="ferritina">
        <input id="u494_input" type="text" name="ferritina" value=""/>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u495" class="ax_default label">
        <div id="u495_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u496" class="text">
          <p><span>g/dL</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u497" class="ax_default label">
        <div id="u497_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u498" class="text">
          <p><span>%</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u499" class="ax_default label">
        <div id="u499_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u500" class="text">
          <p><span>ng/ml</span></p>
        </div>
      </div>
	  
	  <!-- Unnamed (HTML Button) -->
      <div id="u482" class="ax_default html_button">
        <input id="u482_input" type="submit" value="Cadastrar"/>
      </div>
	
	</form>

      <!-- Unnamed (HTML Button) -->
      <div id="u483" class="ax_default html_button">
        <input id="u483_input" type="button" value="Voltar" onClick="history.go(-1)"/>
      </div>
	  
    </div>
	 <!-- Unnamed (Rectangle) -->
      <footer id="u484" class="ax_default box_2">
        <div id="u484_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u485" class="text">
          <p><span>Programa de Pós-Graduação em Tecnologias em Saúde - PPGTS</span></p><p><span>Pontifícia Universidade Católica do Paraná (PUC-PR)</span></p>
        </div>
	 </footer>
  </body>
</html>
