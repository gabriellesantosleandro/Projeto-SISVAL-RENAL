﻿<!DOCTYPE html>
<html>
  <head>
    <title>SISVAL-RENAL: Selecionar paciente</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <link href="resources/css/jquery-ui-themes.css" type="text/css" rel="stylesheet"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/doisoumaispcteencontrado/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-1.7.1.min.js"></script>
    <script src="resources/scripts/jquery-ui-1.8.10.custom.min.js"></script>
    <script src="resources/scripts/prototypePre.js"></script>
    <script src="data/document.js"></script>
    <script src="resources/scripts/prototypePost.js"></script>
    <script src="files/doisoumaispcteencontrado/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
		<style>
		table{
			border-width:0px;
			position:absolute;
			left:50px;
			top:329.5px;
			width:986.5px;
			height:107px;
			font-family:'Arial Bold', 'Arial';
			font-weight:700;
			font-style:normal;
			font-size:15px;
			text-align:center;
			border: 1; 
			border-collapse: collapse;
		}
	</style>
  </head>
  
  <body>
    <div id="base" class="">

      <!-- Fundo (Rectangle) -->
      <div id="u394" class="ax_default paragraph" data-label="Fundo">
        <div id="u394_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u395" class="text" style="display:none; visibility: hidden">
          <p><span></span></p>
        </div>
      </div>

	  <form name="form1" action="buscapcteencontrado.php" method="post" id="doisOuMaisForm" onSubmit="return validaRadio();">

      <!-- CabeçalhoMaisUmResultado (Rectangle) -->
      <div id="u421" class="ax_default box_2" data-label="CabeçalhoMaisUmResultado">
        <div id="u421_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u422" class="text">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; SISVAL-RENAL: RESULTADO DA BUSCA POR PACIENTE</span></p>
        </div>
      </div>
	  
	  <?php
$retorno_resultados = $_POST['retorno_resultados'];
$busca = $_POST['busca'];

$conn = sqlsrv_connect("localhost\SADC",array( "Database"=>"BDSADC")); // Conecta ao banco de dados
$sql = "SELECT * FROM infoPaciente WHERE nomePaciente like '%$busca%' COLLATE latin1_general_ci_ai ORDER BY nascimento ASC"; // Comando SQL para busca de registro no BD
$stmt = sqlsrv_query( $conn, $sql ); 

if( $stmt === false) { // Se a consulta ao BD falhar retorna erro.
    die( print_r( sqlsrv_errors(), true) );
}

echo "  
    <table border=1 border-collapse=\"collapse\"> "."
    <thead> "."
    <tr> "."
    <th height=40px width=125px><b><font-size:17px>SELECIONAR</font></b></th> "."
    <th height=40px width=520px><b><font-size:17px>NOME</font></b></th> "."
    <th height=40px width=140px><b><font-size:17px>DATA DE NASCIMENTO</font></b></th> "."
    <th height=40px width=140px><b><font-size:17px>PRONTUÁRIO</font></b></th> "."
    </tr> "."
    </thead> "."
    <tbody> ";
    
$seleciona = 1;	

while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) { //Imprime na tela enquanto ainda existir linhas no array (coluna do id) 

$codPaciente = $row['codPaciente'];
$nomePaciente = $row['nomePaciente'];
$nascimento = $row['nascimento']->format('d/m/y');
$prontuario = $row['prontuario'];

if ($seleciona == 1){
	
	echo "<tr>"."
        <td height=35px><input type=\"radio\" name=\"codPaciente\" value=\"$codPaciente\" checked></td>"."
		<td><input type=\"hidden\" name=\"nomePaciente\" value=\"$nomePaciente\">". $nomePaciente . "</td> "."
		<td><input type=\"hidden\" name=\"nascimento\" value=\"$nascimento\">". $nascimento . "</td> "."
		<td><input type=\"hidden\" name=\"prontuario\" value=\"$prontuario\">". $prontuario; "</td> ";	 

		} else{
	echo "<tr>"."
        <td height=35px><input type=\"radio\" name=\"codPaciente\" value=\"$codPaciente\"></td>"."
		<td><input type=\"hidden\" name=\"nomePaciente\" value=\"$nomePaciente\">". $nomePaciente . "</td> "."
		<td><input type=\"hidden\" name=\"nascimento\" value=\"$nascimento\">". $nascimento . "</td> "."
		<td><input type=\"hidden\" name=\"prontuario\" value=\"$prontuario\">". $prontuario; "</td> ";
}
$seleciona = 2;

}
	  
 echo "</tr>"."
		<tr> "."
		<td> "."
		<div id=\"u424\" class=\"ax_default box_2\" data-label=\"Rodapé\">"."
        <div id=\"u424_div\" class=\"\"></div>"."
        <div id=\"u425\" class=\"text\">"."
          <p><span>Programa de Pós-Graduação em Tecnologias em Saúde - PPGTS</span></p><p><span>Pontifícia Universidade Católica do Paraná (PUC-PR)</span></p>"."
        </div>"."
      </div>"."
	  </td> "."
	  </tr> "."
	  </tbody>"."
	  </table>";

sqlsrv_free_stmt( $stmt);
?>

	<!-- BotaoSelecionar (HTML Button) -->
      <div id="u433" class="ax_default html_button" data-label="BotaoBuscar">
        <input id="u433_input" type="submit" value="Selecionar"/>
      </div>

	  </form>
	  
      <!-- BotaoVoltar (HTML Button) -->
      <div id="u423" class="ax_default html_button" data-label="BotaoVoltar">
        <input id="u423_input" type="submit" value="Voltar"/>
      </div>

      <!-- ExplicacaoMaisUmResultado (Rectangle) -->
      <div id="u426" class="ax_default paragraph" data-label="ExplicacaoMaisUmResultado">
        <div id="u426_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u427" class="text">
          <p align="justify"><span style="font-family:'Calibri';font-weight:600;"> Se você NÃO encontrou o paciente que está procurando e quer CADASTRAR UM NOVO </br> PACIENTE, clique em "NOVO PACIENTE".</br></br></span></p>
		  <p align="justify"><span style="font-family:'Calibri';font-weight:600;"> Se você encontrou o paciente que estava procurando, SELECIONE-O e clique em "SELECIONAR".</span></p>
        </div>
      </div>

      <!-- TítuloMaisDeUmResultado (Shape) -->
      <div id="u428" class="ax_default heading_1" data-label="TítuloMaisDeUmResultado">
        <img id="u428_img" class="img " src="images/doisoumaispcteencontrado/t_tulomaisdeumresultado_u428.png"/>
        <!-- Unnamed () -->
        <div id="u429" class="text">
          <p><span>Foi encontrado mais de um paciente com esse nome...</span></p>
        </div>
      </div>

      <!-- ImgMaisUmResultado (Image) -->
      <div id="u430" class="ax_default image" data-label="ImgMaisUmResultado">
        <img id="u430_img" class="img " src="images/doisoumaispcteencontrado/imgmaisumresultado_u430.jpg"/>
        <!-- Unnamed () -->
        <div id="u431" class="text" style="display:none; visibility: hidden">
          <p><span></span></p>
        </div>
      </div>

      <!-- BotaoCadastrar (HTML Button) -->
      <div id="u432" class="ax_default html_button" data-label="BotaoCadastrar">
        <a href="sisval-renal.html#u132"><input id="u432_input" type="submit" value="Novo Paciente"/></a>
      </div>

    </div>
  </body>
</html>
