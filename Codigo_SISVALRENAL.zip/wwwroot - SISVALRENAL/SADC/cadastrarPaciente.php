<?php 

//Função para remover acentuação da busca

function removerAcentos($string){
    return preg_replace(array("/(á|à|ã|â|ä)/","/(Á|À|Ã|Â|Ä)/","/(é|è|ê|ë)/","/(É|È|Ê|Ë)/","/(í|ì|î|ï)/","/(Í|Ì|Î|Ï)/","/(ó|ò|õ|ô|ö)/","/(Ó|Ò|Õ|Ô|Ö)/","/(ú|ù|û|ü)/","/(Ú|Ù|Û|Ü)/","/(ñ)/","/(Ñ)/","/(ç)/","/(Ç)/"),explode(" ","a A e E i I o O u U n N c C"),$string);
}

// Tabela infoPaciente
$nomePaciente = removerAcentos($_POST['nomePaciente']);
$nascimento = $_POST['nascimento'];
$prontuario = $_POST['prontuario'];

// Tabela dadoClinico
$dataInfo = $_POST['dataInfo'];
$tto_dialitico = $_POST['tto_dialitico'];
$exclusao = $_POST['exclusao'];
$dataExame = $_POST['dataExame'];
$hemoglobina = str_replace(",",".",$_POST['hemoglobina']);
$transferrina = str_replace(",",".",$_POST['transferrina']);
$ferritina = str_replace(",",".",$_POST['ferritina']);

/*
echo $nomePaciente."<br>";
echo $nascimento."<br>";
echo $prontuario."<br>";
echo $dataInfo."<br>";
echo $tto_dialitico."<br>";
echo $exclusao."<br>";
echo $dataExame."<br>";
echo $hemoglobina."<br>";
echo $transferrina."<br>";
echo $ferritina."<br>";
*/


//Inserindo informacoes na Tabela infoPaciente
$connect = sqlsrv_connect("localhost\SADC",array( "Database"=>"BDSADC"));

//Valida se o prontuario informado ja existe nos registros
$query = "SELECT * FROM infoPaciente WHERE nomePaciente='$nomePaciente' AND nascimento='$nascimento' AND prontuario='$prontuario'"; // Comando SQL para busca de registro no BD
$busca = sqlsrv_query( $connect, $query ); // Executa a consulta da linha anterior
$valida_duplicidade = 0;


 	while( $row = sqlsrv_fetch_array( $busca, SQLSRV_FETCH_ASSOC) ) { //Grava o dado encontrado no array 
	 $valida_duplicidade++;
	 break;
	};	

if ($valida_duplicidade > 0){
sqlsrv_free_stmt ($busca);
echo"<script language='javascript' type='text/javascript'>window.location.href='mensagens/pacienteJaCadastrado.html'</script>";	
}else{

$query = "INSERT INTO infoPaciente (nomePaciente, nascimento, prontuario) VALUES ('$nomePaciente', '$nascimento', '$prontuario');";

$insert = sqlsrv_query($connect,$query);

        if($insert === false){
          echo"<script language='javascript' type='text/javascript'>alert('Não foi possível inserir essas informações em infoPaciente');window.location.href='sisval-renal.html'</script>";
		  die( print_r( sqlsrv_errors(), true) );
		}    

sqlsrv_free_stmt ($insert);		

// Busca o codPaciente
$query = "SELECT codPaciente FROM infoPaciente WHERE nomePaciente='$nomePaciente' AND nascimento='$nascimento' AND prontuario='$prontuario'"; // Comando SQL para busca de registro no BD
$busca = sqlsrv_query( $connect, $query ); // Executa a consulta da linha anterior
if( $busca === false) { // Se a consulta ao BD falhar retorna erro.
              echo"<script language='javascript' type='text/javascript'>alert('Não foi possível buscar codPaciente');window.location.href='sisval-renal.html'</script>";
	die( print_r( sqlsrv_errors(), true) );
}

while( $row = sqlsrv_fetch_array( $busca, SQLSRV_FETCH_ASSOC) ) { //Imprime na tela enquanto ainda existir linhas no array (coluna do id) 
     $codPaciente = $row['codPaciente'];
	 };	
sqlsrv_free_stmt ($busca);

// Inserindo informacoes na Tabela dadoClinico
$query = "INSERT INTO dadoClinico (dataInfo, tto_dialitico, exclusao, dataExame, hemoglobina, transferrina, ferritina, codPaciente) VALUES ('$dataInfo','$tto_dialitico','$exclusao','$dataExame', '$hemoglobina', '$transferrina', '$ferritina', '$codPaciente');";

$insert = sqlsrv_query($connect,$query);
/*
        if($insert){
		echo "<script language='javascript' type='text/javascript'>window.location.href='mensagens/pacienteCadastrado.html'</script>";
        }else{
          echo"<script language='javascript' type='text/javascript'>alert('Não foi possível cadastrar esse paciente. Por favor contacte o administrador do sistema.');window.location.href='sisval-renal.html'</script>";
        }    
//sqlsrv_free_stmt ($insert);
*/

if($insert === false){
          echo"<script language='javascript' type='text/javascript'>alert('Não foi possível cadastrar esse paciente. Por favor contacte o administrador do sistema.');window.location.href='sisval-renal.html'</script>";
		  die( print_r( sqlsrv_errors(), true) );
		}else{
		  echo "<script language='javascript' type='text/javascript'>window.location.href='mensagens/pacienteCadastrado.html'</script>";
	}    
//sqlsrv_free_stmt ($insert);
};

?>