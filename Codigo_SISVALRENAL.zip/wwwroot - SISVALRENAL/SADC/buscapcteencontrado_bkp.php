﻿<!DOCTYPE html>
<html>
  <head>
    <title>SISVAL-RENAL: Informações do Paciente</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <link href="resources/css/jquery-ui-themes.css" type="text/css" rel="stylesheet"/>
    <link href="resources/css/axure_rp_page.css" type="text/css" rel="stylesheet"/>
    <link href="data/styles.css" type="text/css" rel="stylesheet"/>
    <link href="files/buscapcteencontrado/styles.css" type="text/css" rel="stylesheet"/>
    <script src="resources/scripts/jquery-1.7.1.min.js"></script>
    <script src="resources/scripts/jquery-ui-1.8.10.custom.min.js"></script>
    <script src="resources/scripts/prototypePre.js"></script>
    <script src="data/document.js"></script>
    <script src="resources/scripts/prototypePost.js"></script>
    <script src="files/buscapcteencontrado/data.js"></script>
    <script type="text/javascript">
      $axure.utils.getTransparentGifPath = function() { return 'resources/images/transparent.gif'; };
      $axure.utils.getOtherPath = function() { return 'resources/Other.html'; };
      $axure.utils.getReloadPath = function() { return 'resources/reload.html'; };
    </script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <style>
  #accordion-resizer {
    padding:0px;
	position:absolute;
    top: 285px;
	left: 80px;
	width: 775px;
    height: auto;
  }
  
  table.titulo{
  border-collapse: collapse;
  border: 1px solid black;
  position: relative;
  left: 15px;
  }
  
  tr.titulo{
	border: 1px solid black;
  }
  
  td.titulo{
	cellspacing: 2px;
	padding: 2px;
	border: 1px solid black;
	width:101px;
	height:36px;
	font-family:'Arial Negrito', 'Arial Normal', 'Arial';
	font-weight:700;
	font-style:normal;
	text-align: center;
	font-size: 11pt;
  }
  
  table{
  cellpadding: 0px; 
  border-collapse: collapse;
  border: 1px solid black;
  }
  
  tr, td{
	background: white;
	border: 1px solid black;
	padding:2px;
	border: 1px solid black;
	width:102px;
	height:25px;
	font-family:'Arial Negrito', 'Arial Normal', 'Arial';
	font-weight:500;
	font-style:normal;
	text-align: center;
	font-size: 11pt;
	color: black;
  }
  p#msg {
	font-family:'Calibri';
	font-size: 11.9pt;
	color: #4B0082;
  }
  </style>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#accordion" ).accordion({
    });
 
    $( "#accordion-resizer" ).resizable({
      minHeight: 90,
      minWidth: 720,
      resize: function() {
        $( "#accordion" ).accordion( "refresh" );
      }
    });
	if ( $( "#accordion" ).accordion( "option", "icons" ) ) {
        $( "#accordion" ).accordion( "option", "icons", null );
      }
  } );
  
  </script>
	
	<?php
		$codPaciente = $_POST['codPaciente'];
		
		$conn = sqlsrv_connect("localhost\SADC",array( "Database"=>"BDSADC")); // Conecta ao banco de dados
		$sql = "SELECT nomePaciente,prontuario,nascimento FROM infoPaciente WHERE codPaciente='$codPaciente'"; // Comando SQL para busca de registro no BD
		$stmt = sqlsrv_query( $conn, $sql ); 

		if( $stmt === false) { // Se a consulta ao BD falhar retorna erro.
			die( print_r( sqlsrv_errors(), true) );
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			$nomePaciente = $row['nomePaciente'];
			$prontuario = $row['prontuario'];
			$nascimento = $row['nascimento']->format('d/m/y');
		}
		
		sqlsrv_free_stmt( $stmt);

	?>
	
  </head>
  <body>
    <div id="base" class="">

      <!-- Unnamed (Rectangle) -->
      <div id="u185" class="ax_default paragraph">
        <div id="u185_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u186" class="text">
          <p style="font-size:16px;"><span><br></span></p><p style="font-size:20px;"><span>INFORMAÇÕES DO PACIENTE</span></p>
        </div>
      </div>

      <!-- imgIdentificacao (Image) -->
      <div id="u187" class="ax_default image" data-label="imgIdentificacao">
        <img id="u187_img" class="img " src="images/buscapcteencontrado/imgidentificacao_u187.png"/>
        <!-- Unnamed () -->
        <div id="u188" class="text">
          <p><span></span></p>
        </div>
      </div>

      <!-- Unnamed (Table) -->
      <div id="u189" class="ax_default">

        <!-- Nome (Table Cell) -->
        <div id="u190" class="ax_default table_cell" data-label="Nome">
          <img id="u190_img" class="img " src="images/buscapcteencontrado/nome_u190.png"/>
          <!-- Unnamed () -->
          <div id="u191" class="text">
            <p><span>&nbsp;&nbsp; &nbsp; Nome:</span></p>
          </div>
        </div>

        <!-- InserirNome (Table Cell) -->
        <div id="u192" class="ax_default table_cell" data-label="InserirNome">
          <img id="u192_img" class="img " src="images/buscapcteencontrado/inserirnome_u192.png"/>
          <!-- Unnamed () -->
          <div id="u193" class="text">
            <p><span>&nbsp;&nbsp; &nbsp;<?php echo $nomePaciente ;?></span></p>
          </div>
        </div>

        <!-- DataNasc (Table Cell) -->
        <div id="u194" class="ax_default table_cell" data-label="DataNasc">
          <img id="u194_img" class="img " src="images/buscapcteencontrado/datanasc_u194.png"/>
          <!-- Unnamed () -->
          <div id="u195" class="text">
            <p><span>&nbsp;&nbsp; &nbsp; Data de Nascimento:</span></p>
          </div>
        </div>

        <!-- InserirNascimento (Table Cell) -->
        <div id="u196" class="ax_default table_cell" data-label="InserirNascimento">
          <img id="u196_img" class="img " src="images/buscapcteencontrado/inserirnascimento_u196.png"/>
          <!-- Unnamed () -->
          <div id="u197" class="text">
            <p><span>&nbsp;&nbsp; &nbsp;<?php echo $nascimento;?></span></p>
          </div>
        </div>

        <!-- Prontuario (Table Cell) -->
        <div id="u198" class="ax_default table_cell" data-label="Prontuario">
          <img id="u198_img" class="img " src="images/buscapcteencontrado/prontuario_u198.png"/>
          <!-- Unnamed () -->
          <div id="u199" class="text">
            <p><span>&nbsp;&nbsp; &nbsp; Prontuário:</span></p>
          </div>
        </div>

        <!-- InserirProntuario (Table Cell) -->
        <div id="u200" class="ax_default table_cell" data-label="InserirProntuario">
          <img id="u200_img" class="img " src="images/buscapcteencontrado/inserirprontuario_u200.png"/>
          <!-- Unnamed () -->
          <div id="u201" class="text">
            <p><span>&nbsp;&nbsp; &nbsp;<?php echo $prontuario;?></span></p>
          </div>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u202" class="ax_default box_2">
        <div id="u202_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u203" class="text">
          <p><span>&nbsp;&nbsp; &nbsp; &nbsp; SISVAL-RENAL: INFORMAÇÕES DO PACIENTE</span></p>
        </div>
      </div>

      <!-- Unnamed (Rectangle) -->
      <div id="u206" class="ax_default box_2">
        <div id="u206_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u207" class="text">
          <p><span>Programa de Pós-Graduação em Tecnologias em Saúde - PPGTS</span></p><p><span>Pontifícia Universidade Católica do Paraná (PUC-PR)</span></p>
        </div>
      </div>

	  <div id="accordion-resizer" class="ui-widget-content">
		<table class="titulo"> <tr class="titulo"><td class="titulo">Data da informação</td><td class="titulo">Hemodiálise</td><td class="titulo">Critérios de Exclusão</td><td class="titulo">Data do Exame</td><td class="titulo">Hemoglobina (g/dL)</td><td class="titulo">Transferrina (%)</td><td class="titulo">Ferritina (ng/ml)</td></tr></table>
	  <div id="accordion" padding="0px">
      		
<?php
$linha1=array("","","","","","","","","","");
$linha2=array("","","","","","","","","","");
$linha3=array("","","","","","","","","","");
$linha4=array("","","","","","","","","","");
$linha5=array("","","","","","","","","","");
$linha6=array("","","","","","","","","","");
$linha7=array("","","","","","","","","","");
$linha8=array("","","","","","","","","","");
$linha9=array("","","","","","","","","","");
$linha10=array("","","","","","","","","","");
$tabela=array($linha1,$linha2,$linha3,$linha4,$linha5,$linha6,$linha7,$linha8,$linha9,$linha10);

$conn = sqlsrv_connect("localhost\SADC",array( "Database"=>"BDSADC")); // Conecta ao banco de dados
$sql = "SELECT * FROM dadoClinico WHERE codPaciente='$codPaciente' ORDER BY dataInfo DESC"; // Comando SQL para busca de registro no BD
$stmt = sqlsrv_query( $conn, $sql ); 

if( $stmt === false) { // Se a consulta ao BD falhar retorna erro.
    die( print_r( sqlsrv_errors(), true) );
}

$linha=0;

while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) { //Imprime na tela enquanto ainda existir linhas no array (coluna do id) 
$tabela[$linha][0] = $row['codDadoClinico'];
$tabela[$linha][1] = $row['dataInfo']->format('d/m/y');
$tabela[$linha][2] = $row['tto_dialitico'];
$tabela[$linha][3] = $row['exclusao'];
$tabela[$linha][4] = $row['dataExame']->format('d/m/y');
$tabela[$linha][5] = $row['hemoglobina'];
$tabela[$linha][6] = $row['transferrina'];
$tabela[$linha][7] = $row['ferritina'];

$tto_dialitico = $tabela[$linha][2];
$exclusao = $tabela[$linha][3];
$hemoglobina = $tabela[$linha][5];
$transferrina = $tabela[$linha][6];
$ferritina = $tabela[$linha][7];

require "regras.php";

echo "
	<table> "."
	<tr> "."
	<td> ". $tabela[$linha][1] ."</td> "."
	<td> ". $tabela[$linha][2] ."</td>"."
	<td> ". $tabela[$linha][3] ."</td>"."
	<td> ". $tabela[$linha][4] ."</td>"."
	<td> ". $tabela[$linha][5] ."</td>"."
	<td> ". $tabela[$linha][6] ."</td>"."
	<td> ". $tabela[$linha][7] ."</td>"."
	</tr> "."
	</table> "."
    <div> "."
      <p id=\"msg\"><b> ". $msg1 ."</br>". $msg2 ."</br>". $msg3 ."</br>". $msg4 ."</b></p> "."
    </div>";

if($linha==9){
	break;
};

$linha++;
};

sqlsrv_free_stmt( $stmt);

?>
  
</div>
</div>

      <!-- TituloDadosClínicos (Rectangle) -->
      <div id="u385" class="ax_default paragraph" data-label="TituloDadosClínicos">
        <div id="u385_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u386" class="text">
          <p><span>DADOS CLÍNICOS</span></p>
        </div>
      </div>

      <!-- TítuloIdentificacao (Rectangle) -->
      <div id="u387" class="ax_default paragraph" data-label="TítuloIdentificacao">
        <div id="u387_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u388" class="text">
          <p><span>IDENTIFICAÇÃO</span></p>
        </div>
      </div>
	  
<?php	
echo "  
<input name=\"codPaciente\" type=\"hidden\" value=\"$codPaciente\">
";
?> 
      <!-- Unnamed (Rectangle) -->
      <div id="u390" class="ax_default label">
        <div id="u390_div" class=""></div>
        <!-- Unnamed () -->
        <div id="u391" class="text">
          <p><span><br></span></p><p><span>Aqui são exibidos os últimos DEZ atendimentos com avaliação da anemia prestados a este paciente.</span></p>
        </div>
      </div>
	  
	  <!-- Unnamed (Rectangle) -->
      <div id="uNovo" class="ax_default label">
        <div id="uNovo_div" class=""></div>
        <!-- Unnamed () -->
        <div id="uNovo1" class="text">
          <p><span><br></span></p><p><span>Para cadastrar <b>NOVO DADO CLÍNICO</b> para este paciente clique em <b>"Cadastrar dado clínico"</b>. </br> Para efetuar consulta de um novo paciente clique em <b>"Nova Busca"</b>.</span></p>
        </div>
      </div>
	  
<form action="cadastrardadoclinico.php" method="post" id="cadastrarDCForm">	
	
	<?php	
	echo "  
	<input name=\"codPaciente\" type=\"hidden\" value=\"$codPaciente\">
    <input name=\"nomePaciente\" type=\"hidden\" value=\"$nomePaciente\">
	<input name=\"prontuario\" type=\"hidden\" value=\"$prontuario\">
    <input name=\"nascimento\" type=\"hidden\" value=\"$nascimento\">
	";
	?>
	  
	  <!-- BotaoCadastrarDadoClinico (HTML Button) -->
      <div id="u204" class="ax_default html_button" data-label="BotaoImprimir">
        <input id="u204_input" type="submit" value="Cadastrar dado clínico"/>
      </div>

</form>	  
	  
      <!-- BotaoNovaBusca (HTML Button) -->
      <a href="sisval-renal.html"> <div id="u205" class="ax_default html_button" data-label="BotaoVoltar">
        <input id="u205_input" type="submit" value="Nova busca"/>
      </div> </a>
	  
	  
    </div>
  </body>
</html>
