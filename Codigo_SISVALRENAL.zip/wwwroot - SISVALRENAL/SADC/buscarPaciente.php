<?php

//Função para remover acentuação da busca

function removerAcentos($string){
    return preg_replace(array("/(á|à|ã|â|ä)/","/(Á|À|Ã|Â|Ä)/","/(é|è|ê|ë)/","/(É|È|Ê|Ë)/","/(í|ì|î|ï)/","/(Í|Ì|Î|Ï)/","/(ó|ò|õ|ô|ö)/","/(Ó|Ò|Õ|Ô|Ö)/","/(ú|ù|û|ü)/","/(Ú|Ù|Û|Ü)/","/(ñ)/","/(Ñ)/","/(ç)/","/(Ç)/"),explode(" ","a A e E i I o O u U n N c C"),$string);
}

$busca = removerAcentos($_POST['nomePaciente']);
$conn = sqlsrv_connect("localhost\SADC",array( "Database"=>"BDSADC")); // Conecta ao banco de dados

if( $conn === false ) { // testa a conexão e em caso de erro retorna erro.
    die( print_r( sqlsrv_errors(), true));
	echo "Erro na conexão com o banco de dados";
}

//Valida quantidade de resultados que serao retornados -- COLLATE SQL_Latin1_General_CP1_CI_AS -> Maiúscula e Minúscula COLLATE SQL_Latin1_General_CP1_CI_AI -> Acentuação
$sql = "SELECT codPaciente FROM infoPaciente WHERE nomePaciente like '%$busca%' COLLATE latin1_general_ci_ai"; // Comando SQL para busca de registro no BD

$stmt = sqlsrv_query( $conn, $sql ); 
if( $stmt === false) { // Se a consulta ao BD falhar retorna erro.
    die( print_r( sqlsrv_errors(), true) );
}
$retorno_resultados = 0 ;

while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) { //Conta enquanto existir linhas no array (coluna do id) 
    $retorno_resultados = $retorno_resultados + 1;
    };

sqlsrv_free_stmt( $stmt);

//Se nao houver resultados retorna para pagina inicial
if ($retorno_resultados == 0){
	echo"<script language='javascript' type='text/javascript'>window.location.href='mensagens/pacienteNaoCadastrado.html'</script>";
	};

//Se houver um resultado redireciona as informacoes
if ($retorno_resultados == 1){

$sql = "SELECT * FROM infoPaciente WHERE nomePaciente like '%$busca%' COLLATE latin1_general_ci_ai"; // Comando SQL para busca de registro no BD
$stmt = sqlsrv_query( $conn, $sql ); 

while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) { //Imprime na tela enquanto ainda existir linhas no array (coluna do id) 
$codPaciente = $row['codPaciente'];
$nomePaciente = $row['nomePaciente'];
$prontuario = $row['prontuario'];
$nascimento = $row['nascimento']->format('d/m/y');
};

sqlsrv_free_stmt( $stmt);

echo "  
  <br>
   <form action=\"buscapcteencontrado.php\" method=\"post\" id=\"pacientesForm\">
    <input name=\"codPaciente\" type=\"hidden\" value=\"$codPaciente\">
    <input name=\"nomePaciente\" type=\"hidden\" value=\"$nomePaciente\">
	<input name=\"prontuario\" type=\"hidden\" value=\"$prontuario\">
    <input name=\"nascimento\" type=\"hidden\" value=\"$nascimento\">
   </form>
";
?>

<script type="text/javascript">
   document.getElementById('pacientesForm').submit(); // SUBMIT FORM
</script>

<?php
}else{
	

echo "  
  <br>
   <form action=\"doisoumaispcteencontrado.php\" method=\"post\" id=\"doisOuMaisForm\">
    <input name=\"retorno_resultados\" type=\"hidden\" value=\"$retorno_resultados\">
	<input name=\"busca\" type=\"hidden\" value=\"$busca\">
   </form>
";
?>
<script type="text/javascript">
   document.getElementById('doisOuMaisForm').submit(); // SUBMIT FORM
</script>

<?php
};

?>