<?php

$pergunta1 = $_POST['pergunta1'];
$pergunta2 = $_POST['pergunta2'];
$pergunta3 = $_POST['pergunta3'];
$pergunta4 = $_POST['pergunta4'];
$pergunta5 = $_POST['pergunta5'];
$pergunta6 = $_POST['pergunta6'];
$pergunta7 = $_POST['pergunta7'];
$pergunta8 = $_POST['pergunta8'];
$pergunta9 = $_POST['pergunta9'];
$pergunta10 = $_POST['pergunta10'];
$pergunta11 = $_POST['pergunta11'];
$pergunta12 = $_POST['pergunta12'];
$pergunta13 = $_POST['pergunta13'];

/* Testes...
echo $pergunta1."<br>";
echo $pergunta2."<br>";
echo $pergunta3."<br>";
echo $pergunta4."<br>";
echo $pergunta5."<br>";
echo $pergunta6."<br>";
echo $pergunta7."<br>";
echo $pergunta8."<br>";
echo $pergunta9."<br>";
echo $pergunta10."<br>";
echo $pergunta11."<br>";
echo $pergunta12."<br>";
echo $pergunta13."<br>";
*/

//Inserindo informacoes na Tabela avaliaSistema
$connect = sqlsrv_connect("localhost\SADC",array( "Database"=>"BDSADC"));

$query = "INSERT INTO avaliaSistema (pergunta1, pergunta2, pergunta3, pergunta4, pergunta5, pergunta6, pergunta7, pergunta8, pergunta9, pergunta10, pergunta11, pergunta12, pergunta13) VALUES ('$pergunta1', '$pergunta2', '$pergunta3', '$pergunta4', '$pergunta5', '$pergunta6', '$pergunta7', '$pergunta8', '$pergunta9', '$pergunta10', '$pergunta11', '$pergunta12', '$pergunta13');";

$insert = sqlsrv_query($connect,$query);

        if($insert === false){
          echo"<script language='javascript' type='text/javascript'>alert('Não foi possível inserir suas informações no sistema. Por favor, contacte o administrador.');window.location.href='sisval-renal.html'</script>";
		  die( print_r( sqlsrv_errors(), true) );
		} else {
			echo"<script language='javascript' type='text/javascript'>window.location.href='mensagens/avaliacaoSistemaOk.html'</script>";
		}    

sqlsrv_free_stmt ($insert);

?>