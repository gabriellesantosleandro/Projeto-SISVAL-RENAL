﻿<?php

if ($tto_dialitico != "SIM"){ 
	$msg1 = "Não há critérios de inclusão no protocolo Anemia na Insuficiência Renal Crônica: Reposição de Ferro.";
	$msg2 = "Justificativa: O paciente NÃO está em hemodiálise.";
	$msg3 = "";
	$msg4 = "";
} else if ($exclusao != "NAO"){
	$msg1 = "Não há critérios de inclusão no protocolo Anemia na Insuficiência Renal Crônica: Reposição de Ferro.";
	$msg2 = "Justificativa: O paciente apresenta algum dos critérios de exclusão: hemocromatose, hemossiderose, anemia hemolítica ou hipersensibilidade ao Sacarato de Hidróxido de Ferro III.";
	$msg3 = "";
	$msg4 = "";
}else if(($hemoglobina == NULL || $hemoglobina == 0)&&($transferrina == NULL || $transferrina == 0)&&($ferritina == NULL || $ferritina == 0)){
	$msg1 = "Não foi possível executar as regras do SISVAL-RENAL nesse dado clínico.";
	$msg2 = "Justificativa: O valor da hemoglobina, da transferrina e da ferritina são NULOS ou ZERO.";
	$msg3 = "";
	$msg4 = "";
}else if(($transferrina == NULL || $transferrina == 0)&&($hemoglobina == NULL || $hemoglobina == 0)){
	$msg1 = "Não foi possível executar as regras do SISVAL-RENAL nesse dado clínico.";
	$msg2 = "Justificativa: O valor da hemoglobina e da transferrina são NULOS ou ZERO.";
	$msg3 = "";
	$msg4 = "";
}else if(($hemoglobina == NULL || $hemoglobina == 0)&&($ferritina == NULL || $ferritina == 0)){
	$msg1 = "Não foi possível executar as regras do SISVAL-RENAL nesse dado clínico.";
	$msg2 = "Justificativa: O valor da hemoglobina e da ferritina são NULOS ou ZERO.";
	$msg3 = "";
	$msg4 = "";
}else if(($transferrina == NULL || $transferrina == 0)&&($ferritina == NULL || $ferritina == 0)){
	$msg1 = "Não foi possível executar as regras do SISVAL-RENAL nesse dado clínico.";
	$msg2 = "Justificativa: O valor da transferrina e da ferritina são NULOS ou ZERO.";
	$msg3 = "";
	$msg4 = "";
}else if($hemoglobina == NULL || $hemoglobina == 0){
	$msg1 = "Não foi possível executar as regras do SISVAL-RENAL nesse dado clínico.";
	$msg2 = "Justificativa: O valor da hemoglobina é NULO ou ZERO.";
	$msg3 = "";
	$msg4 = "";
}else if($transferrina == NULL || $transferrina == 0){
	$msg1 = "Não foi possível executar as regras do SISVAL-RENAL nesse dado clínico.";
	$msg2 = "Justificativa: O valor da transferrina é NULO ou ZERO.";
	$msg3 = "";
	$msg4 = "";
}else if($ferritina == NULL || $ferritina == 0){
	$msg1 = "Não foi possível executar as regras do SISVAL-RENAL nesse dado clínico.";
	$msg2 = "Justificativa: O valor da ferritina é NULO ou ZERO.";
	$msg3 = "";
	$msg4 = "";
} else if ($hemoglobina >= 11){ 
	$msg1 = "Como a hemoglobina é igual ou maior a 11 g/dL, a diretriz Anemia na Insuficiência Renal Crônica: Reposição de Ferro recomenda SUSPENDER O USO DO FERRO PARENTERAL. Contudo, foi constatado que também é prática da Instituição Pró-Rim fazer uso de DOSE MANUTENÇÃO ou DOSE ATAQUE dependendo dos valores da Transferrina e da Ferritina.";
	$msg2 = "";
	$msg3 = "";
	$msg4 = "";
}else if ($transferrina < 20 && $ferritina <200){
	$msg1 = "Diagnóstico: DEFICIÊNCIA ABSOLUTA DE FERRO."; 
	$msg2 =	"Dose Recomendada: ATAQUE."; 
	$msg3 = "Sacarato de Ferro 100 mg - Administrar 10 ampolas EV em 10 sessões de hemodiálise.";
	$msg4 = "Justificativa: O valor da transferrina está abaixo de 20% e da ferritina abaixo de 200 ng/ml.";
}else if ($transferrina < 20 && $ferritina >= 200 && $ferritina <= 800){
	$msg1 = "Diagnóstico: DEFICIÊNCIA RELATIVA DE FERRO."; 
	$msg2 =	"Dose Recomendada: ATAQUE."; 
	$msg3 = "Sacarato de Ferro 100 mg - Administrar 10 ampolas EV em 10 sessões de hemodiálise.";
	$msg4 = "Justificativa: O valor da transferrina está abaixo de 20% e o da ferritina entre 200 e 800 ng/ml.";
} else if ($transferrina < 20 && $ferritina > 800){
	$msg1 = "DOSE RECOMENDADA: ATAQUE OU MANUTENÇÃO."; 
	$msg2 =	"DOSE ATAQUE: Sacarato de Ferro 100 mg - Administrar 10 ampolas EV em 10 sessões de hemodiálise."; 
	$msg3 = "DOSE MANUTENÇÃO: Sacarato de Ferro 100 mg - Administrar 1 ampola EV a cada 15 dias.";
	$msg4 = "Justificativa: O valor da transferrina está abaixo de 20% e o da ferritina acima de 800 ng/ml.";
} else if ($transferrina >= 20 && $transferrina <= 50 && $ferritina <= 200){
	$msg1 = "DOSE RECOMENDADA: ATAQUE OU MANUTENÇÃO."; 
	$msg2 =	"DOSE ATAQUE: Sacarato de Ferro 100 mg - Administrar 10 ampolas EV em 10 sessões de hemodiálise."; 
	$msg3 = "DOSE MANUTENÇÃO: Sacarato de Ferro 100 mg - Administrar 1 ampola EV a cada 15 dias.";
	$msg4 = "Justificativa: O valor da transferrina está entre 20% e 50% e o da ferritina abaixo ou igual a 200 ng/ml.";
} else if ($transferrina >= 20 && $transferrina <= 50 && $ferritina > 200){
	$msg1 = "DOSE RECOMENDADA: MANUTENÇÃO.";  
	$msg2 = "DOSE MANUTENÇÃO: Sacarato de Ferro 100 mg - Administrar 1 ampola EV a cada 15 dias.";
	$msg3 = "Justificativa: O valor da transferrina está entre 20% e 50% e o da ferritina acima de 200 ng/ml.";	
	$msg4 = "";
} else if ($transferrina > 50 && $ferritina <= 800){
	$msg1 = "DOSE RECOMENDADA: MANUTENÇÃO OU INTERROMPER USO DE FERRO PARENTERAL."; 
	$msg2 = "DOSE MANUTENÇÃO: Sacarato de Ferro 100 mg - Administrar 1 ampola EV a cada 15 dias.";
	$msg3 = "Justificativa: O valor da transferrina está acima de 50% e da ferritina abaixo de 800 ng/ml.";
	$msg4 = "";
}else if ($transferrina > 50 && $ferritina > 800){
	$msg1 = "RECOMENDAÇÃO: INTERROMPER USO DE FERRO PARENTERAL.";
	$msg2 = "Justificativa: O valor da transferrina está acima de 50% e da ferritina acima de 800 ng/ml.";
	$msg3 = "Existe exceção quando o paciente precisa de doses altas de Alfaepoetina, em que a reposição de ferro endovenosa pode ser recomendada em valores de ferritina sérica de até 1.200 mg/dl."; 
	$msg4 = "";
}
 
?>

