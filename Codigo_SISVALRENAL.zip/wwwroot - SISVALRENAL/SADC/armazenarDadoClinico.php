<?php
// Tabela infoPaciente
$codPaciente = $_POST['codPaciente'];
$nomePaciente = $_POST['nomePaciente'];
$prontuario = $_POST['prontuario'];
$nascimento = $_POST['nascimento'];


// Tabela dadoClinico

$dataInfo = $_POST['dataInfo'];
$tto_dialitico = $_POST['tto_dialitico'];
$exclusao = $_POST['exclusao'];
$dataExame = $_POST['dataExame'];
$hemoglobina = str_replace(",",".",$_POST['hemoglobina']);
$transferrina = str_replace(",",".",$_POST['transferrina']);
$ferritina = str_replace(",",".",$_POST['ferritina']);


$connect = sqlsrv_connect("localhost\SADC",array( "Database"=>"BDSADC"));
// Inserindo informacoes na Tabela dadoClinico

$query = "INSERT INTO dadoClinico (dataInfo, tto_dialitico, exclusao, dataExame, hemoglobina, transferrina, ferritina, codPaciente) VALUES ('$dataInfo','$tto_dialitico','$exclusao', '$dataExame', '$hemoglobina', '$transferrina', '$ferritina', '$codPaciente');";
$insert = sqlsrv_query($connect,$query);

if( $insert === false) { // Se a consulta ao BD falhar retorna erro.
              echo"<script language='javascript' type='text/javascript'>alert('Não foi possível cadastrar');window.location.href='buscapcteencontrado.php'</script>";
	die( print_r( sqlsrv_errors(), true) );
}
      
echo"<script language='javascript' type='text/javascript'>alert('Informações cadastradas com sucesso!')'</script>";

echo "  
  <br>
   <form action=\"buscapcteencontrado.php\" method=\"post\" id=\"pacientesForm\">
    <input name=\"codPaciente\" type=\"hidden\" value=\"$codPaciente\">
    <input name=\"nomePaciente\" type=\"hidden\" value=\"$nomePaciente\">
	<input name=\"prontuario\" type=\"hidden\" value=\"$prontuario\">
    <input name=\"nascimento\" type=\"hidden\" value=\"$nascimento\">
   </form>
";
?>

<script type="text/javascript">
   document.getElementById('pacientesForm').submit(); // SUBMIT FORM
</script>

<?php

sqlsrv_free_stmt ($insert);

?>