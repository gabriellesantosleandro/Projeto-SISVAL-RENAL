insert into dbo.dadoClinico1 (dataInfo, tto_dialitico, exclusao, dataExame, hemoglobina, transferrina, ferritina, codPaciente)
select dataInfo, tto_dialitico, exclusao, dataExame, hemoglobina, transferrina, ferritina, codPaciente
from dbo.dadoClinico
order by codDadoClinico asc