create table infoPaciente (
codPaciente int identity (1,1) PRIMARY KEY NOT NULL,
nomePaciente nvarchar(50) NOT NULL,
nascimento date NOT NULL,
prontuario nchar(10) NOT NULL);