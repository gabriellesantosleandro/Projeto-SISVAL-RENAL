create table dadoClinico (
codDadoClinico int identity (1,1) PRIMARY KEY NOT NULL,
dataInfo date NOT NULL,
tto_dialitico text NOT NULL,
exclusao text NOT NULL,
dataExame date NOT NULL,
hemoglobina float NOT NULL,
transferrina int NOT NULL,
ferritina int NOT NULL,
respostaSAD text,
codPaciente int FOREIGN KEY REFERENCES infoPaciente(codPaciente) NOT NULL);